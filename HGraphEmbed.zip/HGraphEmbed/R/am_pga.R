#' Projected Gradient Ascent for Embedding Models
#'
#' This function implements the projected gradient ascent algorithm for optimizing embedding models.
#'
#' @param Y A matrix representing the hyperedges.
#' @param F0 Initial values for factors.
#' @param Z0 Initial values for loadings.
#' @param alpha0 Initial values for alpha.
#' @param eta Step size parameter for gradient ascent.
#' @param nT Number of iterations for the optimization process.
#'
#' @return A list containing:
#' \item{F_hat}{Optimized factors.}
#' \item{Z_hat}{Optimized loadings.}
#' \item{alpha_hat}{Optimized alpha values.}
#' \item{lkl}{Log-likelihood values for each iteration.}
#'
#' @export
am_pga <- function(Y, F0, Z0, alpha0, eta = 1, nT = 100) {
  .Call("am_pga_cpp", Y, F0, Z0, alpha0, eta, nT)
}