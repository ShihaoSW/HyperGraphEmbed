# R/usvd.R

usvd <- function(V, K, low_p, up_p) {
  V.svd <- svd(V)
  sigmas <- V.svd$d[1:K]
  u <- V.svd$u[, 1:K]
  v <- V.svd$v[, 1:K]
  P0 <- u %*% diag(sigmas) %*% t(v)
  
  P <- trim_p(P0, low_p, up_p)
  Theta <- logit(P)
  
  return(Theta)
}