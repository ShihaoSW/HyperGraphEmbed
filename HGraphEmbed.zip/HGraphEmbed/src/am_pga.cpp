#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
List am_pga_cpp(NumericMatrix Y, NumericMatrix F0, NumericMatrix Z0, NumericVector alpha0, double eta = 1, int nT = 100) {
  int m = Y.nrow();
  int n = Y.ncol();
  
  NumericMatrix F_new = clone(F0);
  NumericMatrix Z_new = clone(Z0);
  NumericVector alpha_new = clone(alpha0);
  
  NumericVector lkl(nT);
  lkl[0] = Log_likelihood_ori(Y, alpha0, F0, Z0);
  
  for (int t = 1; t < nT; t++) {
    NumericMatrix F_old = clone(F_new);
    NumericMatrix Z_old = clone(Z_new);
    NumericVector alpha_old = clone(alpha_new);
    
    NumericMatrix Theta = rep(1, m) * transpose(alpha_old) + F_old * transpose(Z_old);
    
    F_new = F_old + eta * (Y - invlogit(Theta)) * Z_old;
    Z_new = Z_old + eta * transpose(Y - invlogit(Theta)) * F_old;
    alpha_new = alpha_old + eta / (2 * m) * transpose(Y - invlogit(Theta)) * rep(1, m);
    
    F_new = F_new - rep(1, m) * transpose(colMeans(F_new));
    lkl[t] = Log_likelihood_ori(Y, alpha_new, F_new, Z_new);
  }
  
  return List::create(Named("F_hat") = F_new,
                      Named("Z_hat") = Z_new,
                      Named("alpha_hat") = alpha_new,
                      Named("lkl") = lkl);
}