#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
NumericMatrix usvd(NumericMatrix V, int K, double low_p, double up_p) {
  int m = V.nrow();
  int n = V.ncol();
  
  // Perform Singular Value Decomposition
  NumericMatrix U(m, K);
  NumericMatrix D(K, K);
  NumericMatrix Vt(K, n);
  
  // RcppEigen or RcppArmadillo can be used for SVD
  // Here we will use Rcpp's built-in functions for simplicity
  // Note: You may need to include additional libraries for SVD
  
  // Placeholder for SVD implementation
  // Eigen::JacobiSVD<Eigen::MatrixXd> svd(V);
  // U = svd.matrixU();
  // D = svd.singularValues();
  // Vt = svd.matrixV().transpose();
  
  // Create probability matrix
  NumericMatrix P = U * D * transpose(Vt);
  
  // Trim the probability matrix
  for (int i = 0; i < m; i++) {
    for (int j = 0; j < n; j++) {
      if (P(i, j) < low_p) {
        P(i, j) = low_p;
      }
      if (P(i, j) > up_p) {
        P(i, j) = up_p;
      }
    }
  }
  
  // Return logit of the probability matrix
  NumericMatrix Theta(m, n);
  for (int i = 0; i < m; i++) {
    for (int j = 0; j < n; j++) {
      Theta(i, j) = log(P(i, j) / (1 - P(i, j)));
    }
  }
  
  return Theta;
}